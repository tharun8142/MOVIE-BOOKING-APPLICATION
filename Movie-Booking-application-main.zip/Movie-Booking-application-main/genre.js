let genres = [
    {
        id: 1,
        name: "Action"
    },
    {
        id: 2,
        name: "Sci-Fi"
    },
    {
        id: 3,
        name: "Drama"
    }
]

export default genres;
//       //