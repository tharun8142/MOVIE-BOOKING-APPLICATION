export const BASE_URL = 'ec2-18-217-212-15.us-east-2.compute.amazonaws.com:4000/movie-ticket-booking';
//       //